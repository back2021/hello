package java17_JDBC;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class MemberDAO { //JDBC ���α׷� �޼ҵ� ����
	
	DBManager dbm = DBManager.getInstance();
	
	Connection conn = null; //DB����
	PreparedStatement pstmt = null; //sql
	ResultSet rs = null; //select ��� �� ������
	
	public int custnoMax() throws SQLException { //ȸ����ȣ �ڵ� ����
		String sql ="select max(custno) as cno from member";
		
		conn = dbm.getConnection(); //db����
		pstmt = conn.prepareStatement(sql); //sql���� �����ϱ� ���ؼ� �غ��۾�
		rs = pstmt.executeQuery(); //sql���� 
		//�˻��� ���� ó���Ҷ��� select ���� ���� ���
		int cno=0;
		while(rs.next()) {
			cno = rs.getInt("cno");
		}
		return cno;
	}
	public int memberInsert(MemberVO mvo) throws SQLException {
		
		
		String sql ="insert into member values (?,?,?,?,?,?,?)";
		
		conn = dbm.getConnection(); //DB����
		pstmt = conn.prepareStatement(sql); //sql���� �غ�
		pstmt.setInt(1, mvo.getCustno());
		pstmt.setString(2, mvo.getCustname());
		pstmt.setString(3, mvo.getPhone());
		pstmt.setString(4, mvo.getAddress());
		pstmt.setString(5, mvo.getJoindate());
		pstmt.setString(6, mvo.getGrade());
		pstmt.setString(7, mvo.getCity());
		
		int result = pstmt.executeUpdate(); //����
		return result;
	}
	
	public List<MemberVO> memberSelect() throws Exception {
		
		String sql = "select * from member order by custname asc";
		
		conn = dbm.getConnection();
		pstmt = conn.prepareStatement(sql);
		rs = pstmt.executeQuery();
		
		List<MemberVO> amo = new ArrayList<MemberVO>();
		
		while(rs.next()) {
			
			MemberVO vo = new MemberVO();
			
			vo.setCustno(rs.getInt("custno"));
			vo.setCustname(rs.getString("custname"));
			vo.setPhone(rs.getString("phone"));
			vo.setAddress(rs.getString("address"));
			vo.setJoindate(rs.getString("joindate"));
			vo.setGrade(rs.getString("grade"));
			vo.setCity(rs.getString("city"));
			
			amo.add(vo);
		}
		return amo;
	}
	
	public int memberDelete(int sno) throws Exception {
		
		//String sql = "delete member where custno = "+sno;
		String sql = "delete member where custno = ?";
		
		conn = dbm.getConnection();
		pstmt= conn.prepareStatement(sql);
		pstmt.setInt(1, sno);
		int result =pstmt.executeUpdate();
		
		return result;
		
	}
	
	public MemberVO memberUpdate(int sno) throws SQLException {
		
		String sql = "select * from member where custno ="+sno;
		
		conn = dbm.getConnection();
		pstmt = conn.prepareStatement(sql);
		rs = pstmt.executeQuery();
		MemberVO mvo = null;
		while(rs.next()) {
			mvo = new MemberVO();
			mvo.setCustno(rs.getInt("custno"));
			mvo.setCustname(rs.getString("custname"));
			mvo.setPhone(rs.getString("phone"));
			mvo.setJoindate(rs.getString("joindate"));
			mvo.setAddress(rs.getString("address"));
			mvo.setGrade(rs.getString("grade"));
			mvo.setCity(rs.getString("city"));
		}
		
		return mvo;
	}
	
	public void memberUpdatePro(MemberVO mvo1) throws SQLException {
		
		String sql = "update member set grade=?,city=? where custno=?";
		
		conn = dbm.getConnection();
		
		pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, mvo1.getGrade());
		pstmt.setString(2, mvo1.getCity());
		pstmt.setInt(3, mvo1.getCustno());
		
		pstmt.executeUpdate();
		
		
	}
	
}
