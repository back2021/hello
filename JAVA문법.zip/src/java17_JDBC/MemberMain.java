package java17_JDBC;

import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

public class MemberMain {

	public static void main(String[] args) throws Exception {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("ȸ������ ������Ʈ");
		while(true) {
			System.out.print("[1]�Է�[2]���[3]����[4]����[0]���� ");
			int menu = sc.nextInt();
			MemberDAO dao = new MemberDAO();
			int sno = 0;
			int result=0;
			switch(menu) {
			case 1:
				
				int custno = dao.custnoMax()+1;
				
				System.out.println("ȸ����ȣ : "+custno);
				
				System.out.print("ȸ���̸� : ");
				String custname = sc.next();
				System.out.print("��ȭ��ȣ : ");
				String phone = sc.next();
				System.out.print("�ּ� : ");
				String address = sc.next();
				System.out.print("�Ի���(yyyymmdd) : ");
				String joindate = sc.next();
				System.out.print("���[A]VIP[B]�Ϲ�[C]����: ");
				String grade = sc.next();
				System.out.print("������ȣ[02]����[03]����[04]�λ� : ");
				String city = sc.next();
				
				MemberVO mvo = new MemberVO();
				mvo.setCustno(custno);
				mvo.setCustname(custname);
				mvo.setPhone(phone);
				mvo.setAddress(address);
				mvo.setJoindate(joindate);
				mvo.setGrade(grade);
				mvo.setCity(city);
				
				result = dao.memberInsert(mvo);
				if(result >0) {
					System.out.println("�ڷ��߰� �Ϸ�");
				}
				break;
			case 2:
				
				List<MemberVO> lmv = dao.memberSelect();
				
				for(int i=0; i<lmv.size();i++) {
					System.out.print(lmv.get(i).getCustno()+" ");
					System.out.print(lmv.get(i).getCustname()+" ");
					System.out.print(lmv.get(i).getPhone()+" ");
					System.out.print(lmv.get(i).getAddress()+" ");
					System.out.print(lmv.get(i).getJoindate().substring(0,10)+" ");
					System.out.print(lmv.get(i).getGrade()+" ");
					System.out.println(lmv.get(i).getCity()+" ");
				}
				break;
			case 3:
				System.out.print("ȸ������ ��ȣ �Է� ");
				sno= sc.nextInt();
				
				MemberVO mu = dao.memberUpdate(sno);
				
				int custno1=mu.getCustno();
				String custname1=mu.getCustname();
				String phone1=mu.getPhone();
				String address1=mu.getAddress();
				String joindate1=mu.getJoindate();
				
				System.out.println("ȸ����ȣ : "+custno1);
				System.out.println("ȸ���̸� : "+custname1);
				//System.out.printf("��ȭ��ȣ (%s): ",mu.getPhone());
				//String phone1 = sc.next();
				System.out.println("��ȭ��ȣ : "+phone1);
				System.out.println("ȸ���ּ� : "+address1);
				System.out.println("�������� : "+joindate1.substring(0,10));
				System.out.printf("ȸ����� [%s] >> ",mu.getGrade());
				String grade1 = sc.next();
				System.out.printf("�����ڵ� [%s] >>",mu.getCity());
				String city1 = sc.next();
				
				MemberVO mvo1 = new MemberVO();
				
				mvo1.setCustno(custno1);
				mvo1.setCustname(custname1);
				mvo1.setPhone(phone1);
				mvo1.setAddress(address1);
				mvo1.setJoindate(joindate1);
				mvo1.setGrade(grade1);
				mvo1.setCity(city1);
				
				dao.memberUpdatePro(mvo1);
				
				break;
			case 4:
				System.out.print("ȸ��Ż�� ��ȣ �Է�");
				sno= sc.nextInt();
				
				result = dao.memberDelete(sno);
				if(result > 0) {
					System.out.println("ȸ��Ż�� ó�� �Ϸ�");
				}
				break;
			case 0:
				System.exit(-1);
			}
		}
		
		
	}

}
