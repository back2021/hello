package java09_Object;

import java.util.Scanner;

class NameCard{
	//�̸�(name), ��ȭ��ȣ(tel), �̸���(email),�ּ�(addr)
	//
	String name;
	String tel;
	String email;
	String addr;
	
	//
	public NameCard(){}
	public NameCard(String name,String tel,String email,String addr) {
		this.name=name;
		this.tel=tel;
		this.email=email;
		this.addr=addr;
	}
	public void cardPrint() {
		System.out.println(name+" "+tel+" "+email+" "+addr);
	}
}// NameCard

public class Java03 {

	public static void main(String[] args) {
		// ���԰���
		Scanner sc = new Scanner(System.in);
		for(int i=0;i<3;i++) {
			System.out.print("�̸� : ");
			String name = sc.next();
			System.out.print("��ȭ��ȣ : ");
			String tel = sc.next();
			System.out.print("�̸��� : ");
			String email = sc.next();
			System.out.print("�ּ� : ");
			String addr = sc.next();
			NameCard nc = new NameCard(name,tel,email,addr);
			nc.cardPrint();
		}// for
		
		/*
		int i =0;
		do{
			i=i+1
			sysout("�̸� ��ȭ �̸��� �ּ� �Է�")
			String name = sc.next();
			String tel = sc.next();
			String email = sc.next();
			String addr = sc.next();
			NameCard nc = new NameCard(name,tel,email,addr);
			nc.cardPrint();
		}while(i<=3)
		*/

	}// main

}
