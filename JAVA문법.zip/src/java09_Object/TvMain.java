package java09_Object;

public class TvMain {

	public static void main(String[] args) {
		Tv tv = new Tv("���",true,26);
		tv.power();
		tv.channel=13;
		System.out.println(tv.channel);
		tv.channelUp();
		System.out.println(tv.channel);
		tv.channelDown();
		System.out.println(tv.channel);

	}// main

}
