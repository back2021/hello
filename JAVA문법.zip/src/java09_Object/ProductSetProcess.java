package java09_Object;

import java.util.Scanner;

public class ProductSetProcess {
	Scanner sc = new Scanner(System.in);
	ProductSet[] pArry = new ProductSet[3];
	
	public void inputProduct() {
		for(int i = 0; i < pArry.length; i++) {
			System.out.print("��ǰ�� ���� �ܰ� ������� �Է� >>");
			String name = sc.next();
			int quanty = sc.nextInt();
			int price = sc.nextInt();
			
			ProductSet ps = new ProductSet();
			
			ps.setName(name);
			ps.setQuanty(quanty);
			ps.setPrice(price);
			//ps.setTot(quanty*price);
			pArry[i]=ps;
			
			int tot = totProductPro(ps);
			ps.setTot(tot);
		} // for
		
	} //inputProduct
	
	public int totProductPro(ProductSet p) {
		int Quanty = p.getQuanty();
		int price = p.getPrice();
		int tot = Quanty * price;
		//p.setTot(tot);
		return tot;
	} //totProductPro
	
	public void printProduct() {
		for(int i = 0; i < pArry.length; i++) {
			System.out.print(pArry[i].getName()+" ");
			System.out.print(pArry[i].getQuanty()+" ");
			System.out.print(pArry[i].getPrice()+" ");
			System.out.println(pArry[i].getTot()+" ");
		} // for2
	} //printProduct
	
} // ProductSetProcess
