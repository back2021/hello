package java09_Object;

class SungJuk{
	String name;
	int score;
	int rank=1; //���
	
	public SungJuk() {}
	public SungJuk(String name, int score) {//�����ε�
		super();
		this.name = name;
		this.score = score;
	}
	
	
	
}

public class Java10 {

	public static void main(String[] args) {
		// ��ü �迭
		//int[] iArr=new int[10];
		SungJuk[] iArr= new SungJuk[3];
		
		
//		SungJuk s1=new SungJuk("aa",90);
//		iArr[0] = s1;
		// �ѹ������� ����ÿ�
		iArr[0] =new SungJuk("aa",90);// ��ü ������ �ϸ鼭 �迭�� �����Ѵ�
		
		System.out.println(iArr[0].score);
		
		
//		SungJuk s2=new SungJuk("bb",80);
//		iArr[1] = s2;
		
		iArr[1] =new SungJuk("bb",80);
		
		System.out.println(iArr[1].score);
		
		
//		SungJuk s3 = new SungJuk("cc",100);
//		iArr[2] = s3;
		
		iArr[2] = new SungJuk("cc",100);
		
		
		System.out.println(iArr[2].score);
		
		for (int i=0;i<iArr.length;i++) {
			System.out.println(iArr[i].name +" "+iArr[i].score);
		}
		
		SungJuk tmpl;
		for(int i=0;i<iArr.length;i++) {
			for(int j=i+1;j<iArr.length;j++) {
				if(iArr[i].score>iArr[j].score) {
						tmpl = iArr[i];
						iArr[i] = iArr[j];
						iArr[j] = tmpl;
				}
			}
		}
		
		for (int i=0;i<iArr.length;i++) {
			System.out.println(iArr[i].name +" "+iArr[i].score+" "+iArr[i].rank);
		}
		
		for(int i=0;i<iArr.length;i++) {
			for(int j=0;j<iArr.length;j++) {
				if(iArr[i].score > iArr[j].score) {
					iArr[j].rank++;
				}
			}
		}
		for (int i=0;i<iArr.length;i++) {
			System.out.println(iArr[i].name +" "+iArr[i].score+" "+iArr[i].rank);
		}
		
//		if(iArr[0].score>iArr[1].score) {
//			tmp = iArr[0];
//			iArr[0] = iArr[1];
//			iArr[1] = tmp;
//		}
		
		
		
		
	}// main

}
