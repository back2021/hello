package java09_Object;

class time {
	
	private int hour; //�������� = ĸ��ȭ
	private int minute;
	private int second;
	
	
	public int getHour() {
		return hour;
	}
	public void setHour(int hour) {
		if(hour <0 || hour >23) {
			System.out.println("�� �߸� �Է�");
			return;  //�޼ҵ带 �����ϰ� ������ ������ �ǵ��� ���ÿ�
		}
		this.hour = hour;
	}
	public int getMinute() {
		return minute;
	}
	public void setMinute(int minute) {
		if(minute < 0 || minute > 59) {
			System.out.println("�� �߸� �Է�");
			return;
		}
		this.minute = minute;
	}
	public int getSecond() {
		return second;
	}
	public void setSecond(int second) {
		if(second < 0 || second > 59) {
			System.out.println("�� �߸� �Է�");
			return;
		}
		this.second = second;
	}
	
	@Override
	public String toString() {
		return hour + " " + minute + " " + second;
	}
	
}

public class Java15 {

	public static void main(String[] args) {
		time t = new time();
		
		t.setHour(14);
		t.setMinute(41);
		t.setSecond(50);
		
		t.getHour();
		t.getMinute();
		t.getSecond();
		
		System.out.println(t.toString());
	}

}
