package java09_Object;

public class Java05 {

	public static void main(String[] args) {
		Product p =new Product();
		

	}// main

}
