package java16_collection;

public class Card {

	public static void main(String[] args) {
		// ����
		CardDAO ca = new CardDAO();
		ca.run();
		
	}

}
