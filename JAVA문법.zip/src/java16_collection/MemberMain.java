package java16_collection;

public class MemberMain {

	public static void main(String[] args) {
		MemberManger mm = new MemberManger();
		mm.run();
	}

}
