package java16_collection;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;

public class Score {
	
	int peole;
	Scanner sc;
	HashMap<Integer, FullStackStudent> stu;
	int number = 1;
	
	public Score(){
		sc = new Scanner(System.in);
		stu = new HashMap<Integer, FullStackStudent>();
	}
	
	public void input(FullStackStudent st) {
		sc = new Scanner(System.in);
		
		System.out.print("�̸� : ");
		String name= sc.next();
		st.setName(name);
		System.out.print(name + " of kor : ");
		int kor= sc.nextInt();
		st.setKor(kor);
		System.out.print(name + " of eng : ");
		int eng = sc.nextInt();
		st.setEng(eng);
		System.out.print(name + " of mat : ");
		int mat = sc.nextInt();
		st.setMat(mat);
		
		st.setSum(kor, eng, mat); //�հ�, ���
		
		st.result();
		
		stu.put(number, st);
		number = number + 1;
	}
	
	public void output() {
		Set<Integer> keySet = stu.keySet();
		Iterator<Integer> it = keySet.iterator(); 
		while(it.hasNext()) {
			int key = it.next();
			System.out.println("name : "+stu.get(key).getName());
			System.out.println("kor : "+stu.get(key).getKor());
			System.out.println("mat : "+stu.get(key).getMat());
			System.out.println("eng : "+stu.get(key).getEng());
			System.out.println("sum : "+stu.get(key).getSum());
			System.out.println("avg : "+stu.get(key).getAvg());
			System.out.println();
		}
	}
	
	public void modify() {
		System.out.print("Who key? ");
		Integer key1 = sc.nextInt();
		
		Set<Integer> keySet = stu.keySet();
		Iterator<Integer> it = keySet.iterator(); 
		while(it.hasNext()) {
			Integer key2 = it.next();
			if(key1.equals(key2)) {
				System.out.println(stu.get(key1).getName()+"�� ���� �Է�");
				int kor= sc.nextInt();
				System.out.println(stu.get(key1).getName()+"�� ���� �Է�");
				int eng = sc.nextInt();
				System.out.println(stu.get(key1).getName()+"�� ���� �Է�");
				int mat = sc.nextInt();
				
				stu.get(key1).setSum(kor, eng, mat);
			}
		}
		
	}
	
	public void delete() {
		System.out.print("Who delete key? ");
		//Integer key1 = sc.nextInt();
		Integer key = sc.nextInt();
		 for(int i=1;i<=stu.size();i++){
		 	if(key == i){
		 		stu.remove(key);
	 		}
		}
 		
//		Set<Integer> keySet = stu.keySet();
//		Iterator<Integer> it = keySet.iterator(); 
//		while(it.hasNext()) {
//			Integer key2 = it.next();
//			if(key1.equals(key2)) {
//				stu.remove(key1);
//			}
//		}
		 
	}
	
	
	
} 
