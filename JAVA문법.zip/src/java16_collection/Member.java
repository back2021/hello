package java16_collection;

public class Member {
	int num;
	String name;
	
	public Member() {}
	
	public Member(int num, String name) {
		super();
		this.num = num;
		this.name = name;
	}
	
	
	public int getNum() {
		return num;
	}

	public void setNum(int num) {
		this.num = num;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	
	@Override
	public String toString() {
		return "Member [num=" + num + ", name=" + name + "]";
	}
	
	
}
