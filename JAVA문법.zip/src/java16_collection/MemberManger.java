package java16_collection;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;


public class MemberManger {
	
	Scanner sc = new Scanner(System.in);
	List<Member> mb = new ArrayList<Member>();
	public void run() {
		int key =0;
		
		while((key = selectMenu()) != 0) {
			switch(key) {
			case 1: addMember(); break;
			case 2: removerMember(); break;
			case 3: searchMember(); break;
			case 4: listMember(); break;
			default:System.out.println("�޴����� ����");break;
			}
		}
		System.out.println("������Ʈ ����");
	}//run
	
	public int selectMenu() {
		System.out.print("1.�Է�2.����.3.�˻�4.���0.���� ");
		int key = sc.nextInt();
		sc.nextLine();
		return key;
	} //selectMenu
	
	public void addMember() {
		System.out.print("��ȣ, �̸� �Է� : ");
		int num = sc.nextInt();
		String name = sc.next();
		
		Member mm = new Member(num, name);
		mb.add(mm);
	} //addMember

	public void removerMember() {
		System.out.print("������ ��ȣ �Է� : ");
		int num = sc.nextInt();
		Member mbc = find(num);
		if(mbc == null) {
			System.out.println("������������ȸ��");
		}
		mb.remove(mbc);
		
	} //removerMember

	public void searchMember() {
		System.out.print("�˻��� ȸ�� ��ȣ �Է� : ");
		int num = sc.nextInt();
		Member mbc = find(num);
		if(mbc == null) {
			System.out.println("������������ȸ��");
		}else {
		System.out.println(mbc.toString());
		}
	} //searchMember
	
	public Member find(int num) { //�˻�
		Member mbc = null;
//		for(int i=0; i<mb.size();i++) {
//			if(mb.get(i).num == num) {
//				mbc = mb.get(i);
//			}
//		}
		 for(Member mba : mb){
		 	if(mba.getNum() == num){
		 		mbc =mba;
		 	}
		 }
		return mbc;
	}
	
	public void listMember() {
		for(int i=0;i<mb.size();i++) {
			System.out.println(mb.get(i).toString());
		}
		/*
		 System.out.println("��ü���");
		 int cnt = mb.size();
		 System.out.println("ȸ���� : "+cnt);
		 for(Member m : mb){
		 	System.out.println(m.toString());
		 }
		 */
	} //listMember
}
