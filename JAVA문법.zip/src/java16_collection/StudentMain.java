package java16_collection;

import java.util.Scanner;

public class StudentMain {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		Score score = new Score();
		int i = 0;
		while(true) {
			FullStackStudent student = new FullStackStudent();
			System.out.print("1.�Է�2.����(�̸�)3.����(�̸�)4.��� ");
			int select = sc.nextInt();
			switch(select){
			case 1: score.input(student); i++; break;
			case 2: score.modify(); break;
			case 3: score.delete(); break;
			case 4: score.output(); break;
			default: break;
			}
		}
	}

}
