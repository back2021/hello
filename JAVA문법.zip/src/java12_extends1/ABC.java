package java12_extends1;

class A {
	String aField="a �ʵ�";
	public void aMethod() {
		System.out.println(aField);
	}
}

class B extends A{
	String bField="b �ʵ�";
	public void bMethod() {
		System.out.println(aField);
		System.out.println(bField);
	}
}

class C extends B{
	String cField="c �ʵ�";
	public void cMethod() {
		System.out.println(aField);
		System.out.println(bField);
		System.out.println(cField);
	}
}

public class ABC {
	public static void main(String[] args) {
		System.out.println("-A-");
		A a =new A();
		
		a.aMethod();
		System.out.println("-A-B-");
		B b = new B();
		b.aMethod();
		b.bMethod();
		System.out.println("-A-B-C-");
		C c = new C();
		c.aMethod();
		c.bMethod();
		c.cMethod();
	}
}