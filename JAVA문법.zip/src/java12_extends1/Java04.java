package java12_extends1;

class Sung{
	private int sno;
	private String name;
	
	//�Ű����� �ִ� ������
	
	public int getSno() {
		return sno;
	}
	
	public void setSno(int sno) {
		this.sno = sno;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public void stuPrint() {
		System.out.println(sno+" "+name);
	}
}

class Student extends Sung{
	
	int score;
	
	
	@Override
	public void stuPrint() {
		System.out.println(super.getSno()+" "+super.getName()+" "+this.score+" ");
	}
}

class StudentPro extends Student {
	
	String hakjum;
	
	
	
	public void hakjumProcess(int score) {
		
		if(score>=80) {
			hakjum="�հ�";
		}else {
			hakjum="���հ�";
		}
		
	}
	
	@Override //������
	public void stuPrint() {
		System.out.println(super.getSno()+" "+super.getName()+" "+super.score+" "+this.hakjum);
	}
	
} //StudentPro

public class Java04 {

	public static void main(String[] args) {
		
		StudentPro sp = new StudentPro();
		
		sp.setName("���ڹ�");
		sp.setSno(1101);
		int score=sp.score=90;
		sp.hakjumProcess(score);
		sp.stuPrint();
		
	}

}
