package java12_extends1;

import java.util.Scanner;

class Super{
	int a, b;
	
	public void setA(int a) {
		this.a = a;
	}
	public void setB(int b) {
		this.b = b;
	}
	
	public void sum() {
		System.out.println("add = "+(a+b));
	}
	public void substract() {
		System.out.println("substract = "+(a-b));
	}
	
}

class SubClass extends Super{
	public void mul(){
		System.out.println("mul = "+(a*b));
	}
	public void div(){
		System.out.println("div = "+(a/b));
	}
}

public class CalcMain {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.print("a�� b�� : ");
		int a = sc.nextInt();
		int b = sc.nextInt();
		
		SubClass sub= new SubClass();
		
		sub.setA(a);
		sub.setB(b);
		
		sub.sum();
		sub.substract();
		sub.mul();
		sub.div();
	}

}
