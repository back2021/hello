package java11_singleton;

import java.sql.Connection;

public class Java02 {

	public static void main(String[] args) {
		
		// Java01 j1 = new Java01();
		// j1.instance;
		
		Java01 j1 = Java01.getInstance();
		Connection conn = j1.getConection();
		System.out.println("DB���� �Ǿ����ϴ�");
		
	}

}
