package java08_Array;

import java.util.Arrays;

public class Java08 {

	public static void main(String[] args) {
		// 2���� �迭 : [][]
		// ���� �迭�� �迭�μ� �����ϴ� ��
		
		int[][] array= new int[3][3]; // ���, ����
		
		int count =0;
		for(int i=0;i<3;i++) {
			for(int j=0;j<3;j++) {
				array[i][j] = ++count;
			}
		}
		
		for(int i=0;i<3;i++) {
			for(int j=0;j<3;j++) {
				System.out.print(array[i][j] + " ");
			}
			System.out.println();
		}
		
		int[][] array1= {
				{1,2,3,4},
				{3,4,6,8}
				};
		for(int i=0;i<array1.length;i++) {
			for(int j=0;j<array1[i].length;j++) {
				System.out.print(array1[i][j] + " ");
			}
			System.out.println();
		}
		
		int[][] score = {
				{100,100},
				{90,90,90},
				{80,80,80,80}
				};
		for(int i=0;i<score.length;i++) {
			for(int j=0;j<score[i].length;j++) {
				System.out.print(score[i][j] + " ");
			}
			System.out.println();
		}
		

	}// main

}
